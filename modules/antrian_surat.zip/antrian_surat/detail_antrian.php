<?php
// mencegah direct access file PHP
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    header('location: ../../404.html');
    exit;
}

// Periksa session
if (!isset($_SESSION)) {
    session_start();
}

// Tampilkan error untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Muat autoloader Composer jika ada
if (file_exists('vendor/autoload.php')) {
    require_once 'vendor/autoload.php';
}

// Gunakan class Fpdi yang benar untuk impor PDF
use setasign\Fpdi\Tcpdf\Fpdi;

// Cek hak akses
if (!isset($_SESSION['hak_akses']) || !in_array($_SESSION['hak_akses'], ['SuperAdmin', 'Pimpinan', 'SekretarisPimpinan'])) {
    echo "<script>alert('Akses ditolak!');</script>";
    header('location: ?module=login');
    exit;
}

/**
 * Menggabungkan gambar tanda tangan dengan dokumen PDF
 */
function mergeSignatureWithPDF($original_pdf, $signature_image, $x, $y, $output_path) {
    if (!class_exists('setasign\Fpdi\Tcpdf\Fpdi')) {
        return ['success' => false, 'message' => 'Error: Library FPDI tidak ditemukan. Pastikan Anda telah menjalankan "composer require setasign/fpdi-tcpdf".'];
    }
    
    $pdf = new Fpdi();

    // Validasi file input
    if (!file_exists($original_pdf) || !is_readable($original_pdf)) {
        return ['success' => false, 'message' => 'File PDF asli tidak ditemukan atau tidak bisa dibaca. Path: ' . $original_pdf];
    }
    if (!file_exists($signature_image)) {
        return ['success' => false, 'message' => 'File gambar tanda tangan tidak ditemukan. Path: ' . $signature_image];
    }

    try {
        // Set source file dan dapatkan jumlah halaman
        $page_count = $pdf->setSourceFile($original_pdf);
        if ($page_count === 0) {
            return ['success' => false, 'message' => 'File PDF tidak valid atau kosong.'];
        }

        // Dapatkan template halaman pertama untuk mendapatkan dimensi
        $tplIdx = $pdf->importPage(1);
        $size = $pdf->getTemplateSize($tplIdx);
        $pageWidthMm = $size['width'];
        $pageHeightMm = $size['height'];

        // Log dimensi halaman untuk verifikasi
        error_log("PDF page dimensions: width={$pageWidthMm}mm, height={$pageHeightMm}mm");
        error_log("Signature position input: x={$x}mm, y={$y}mm");

        // Konstanta ukuran tanda tangan
        $signatureWidthMm = 50;
        $signatureHeightMm = 25;

        // Validasi dan koreksi posisi jika perlu
        $correctedX = max(0, min($x, $pageWidthMm - $signatureWidthMm));
        $correctedY = max(0, min($y, $pageHeightMm - $signatureHeightMm));

        if ($correctedX != $x || $correctedY != $y) {
            error_log("Position corrected from ({$x}, {$y}) to ({$correctedX}, {$correctedY})");
        }

        // Proses setiap halaman
        for ($page = 1; $page <= $page_count; $page++) {
            $template_id = $pdf->importPage($page);
            $size = $pdf->getTemplateSize($template_id);
            
            // Tambah halaman dengan orientasi dan ukuran yang sama
            $pdf->AddPage($size['orientation'], [$size['width'], $size['height']]);
            $pdf->useTemplate($template_id);

            // Tambahkan tanda tangan hanya di halaman terakhir
            if ($page === $page_count) {
                // Koordinat Y sudah dalam sistem bottom-left dari JavaScript
                // Tidak perlu konversi lagi karena FPDI menggunakan sistem yang sama
                $finalX = $correctedX;
                $finalY = $correctedY;
                
                error_log("Final signature placement: x={$finalX}mm, y={$finalY}mm, width={$signatureWidthMm}mm, height={$signatureHeightMm}mm");
                
                // Tempatkan gambar tanda tangan
                $pdf->Image($signature_image, $finalX, $finalY, $signatureWidthMm, $signatureHeightMm, 'PNG');
            }
        }

        // Pastikan direktori output ada
        $output_dir = dirname($output_path);
        if (!is_dir($output_dir)) {
            if (!mkdir($output_dir, 0777, true)) {
                return ['success' => false, 'message' => 'Gagal membuat direktori output: ' . $output_dir];
            }
        }

        // Simpan file PDF hasil
        $pdf->Output($output_path, 'F');
        
        // Verifikasi file tersimpan
        if (!file_exists($output_path)) {
            return ['success' => false, 'message' => 'File output tidak berhasil dibuat.'];
        }

        return [
            'success' => true, 
            'file_path' => $output_path, 
            'page_width' => $pageWidthMm, 
            'page_height' => $pageHeightMm,
            'signature_position' => [
                'x' => $finalX,
                'y' => $finalY,
                'width' => $signatureWidthMm,
                'height' => $signatureHeightMm
            ]
        ];

    } catch (Exception $e) {
        error_log("PDF merge error: " . $e->getMessage());
        return ['success' => false, 'message' => 'Error saat memproses PDF: ' . $e->getMessage()];
    }
}
function validateSignaturePosition($x, $y, $pageWidth, $pageHeight, $signatureWidth = 50, $signatureHeight = 25) {
    $errors = [];
    $warnings = [];
    
    if ($x < 0) {
        $errors[] = "Posisi X negatif: {$x}";
    }
    if ($y < 0) {
        $errors[] = "Posisi Y negatif: {$y}";
    }
    if ($x + $signatureWidth > $pageWidth) {
        $warnings[] = "Tanda tangan melebihi batas kanan halaman";
    }
    if ($y + $signatureHeight > $pageHeight) {
        $warnings[] = "Tanda tangan melebihi batas atas halaman";
    }
    
    return [
        'valid' => empty($errors),
        'errors' => $errors,
        'warnings' => $warnings
    ];
}

// Ambil ID pengajuan
$id_pengajuan = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id_pengajuan <= 0) {
    header('location: ?module=antrian_surat');
    exit;
}

// Pastikan koneksi database ada
if (!isset($mysqli)) { die("Koneksi database tidak tersedia."); }

// Ambil data pengajuan
$query = "SELECT p.*, j.nama_jenis, u.nama_user as nama_pengaju FROM tbl_pengajuan p 
          INNER JOIN tbl_jenis j ON p.jenis_dokumen = j.id_jenis 
          INNER JOIN tbl_user u ON p.id_pengaju = u.id_user 
          WHERE p.id_pengajuan = ? AND p.status_pengajuan = 'Menunggu'";
$stmt = mysqli_prepare($mysqli, $query);
mysqli_stmt_bind_param($stmt, "i", $id_pengajuan);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    echo "<script>alert('Data pengajuan tidak ditemukan atau sudah diproses.'); window.location.href = '?module=antrian_surat';</script>";
    exit;
}
$data = mysqli_fetch_assoc($result);
$days_waiting = (strtotime(date('Y-m-d')) - strtotime($data['tanggal_pengajuan'])) / (60 * 60 * 24);

// --- PERBAIKAN: Ambil riwayat tanda tangan pimpinan ---
$id_pimpinan = $_SESSION['id_user'];
$query_ttd = "SELECT file_ttd, MAX(tanggal_ttd) as last_used 
              FROM tbl_pengajuan 
              WHERE id_penandatangan = ? AND file_ttd IS NOT NULL AND file_ttd != '' 
              GROUP BY file_ttd
              ORDER BY last_used DESC 
              LIMIT 6";
$stmt_ttd = mysqli_prepare($mysqli, $query_ttd);
mysqli_stmt_bind_param($stmt_ttd, "i", $id_pimpinan);
mysqli_stmt_execute($stmt_ttd);
$result_ttd = mysqli_stmt_get_result($stmt_ttd);
$riwayat_ttd = [];
while ($row_ttd = mysqli_fetch_assoc($result_ttd)) {
    if (file_exists($row_ttd['file_ttd'])) {
        $riwayat_ttd[] = $row_ttd['file_ttd'];
    }
}

// Proses form
if ($_POST) {
    if (isset($_POST['action'])) {
        // Proses Tolak
        if ($_POST['action'] == 'tolak') {
            $catatan_penolakan = mysqli_real_escape_string($mysqli, $_POST['catatan_penolakan']);
            $update_query = "UPDATE tbl_pengajuan SET status_pengajuan = 'Ditolak', catatan_pimpinan = ?, updated_at = NOW() WHERE id_pengajuan = ?";
            $stmt_update = mysqli_prepare($mysqli, $update_query);
            mysqli_stmt_bind_param($stmt_update, "si", $catatan_penolakan, $id_pengajuan);
            if (mysqli_stmt_execute($stmt_update)) {
                echo "<script>alert('Pengajuan berhasil ditolak.'); window.location.href = '?module=antrian_surat';</script>";
            } else {
                echo "<script>alert('Gagal menolak pengajuan.');</script>";
            }
            exit;
        } 
        // Proses Setujui
        elseif ($_POST['action'] == 'setujui') {
            $project_root = $_SERVER['DOCUMENT_ROOT'] . '/buib_itpln/';
            $ttd_source = $_POST['ttd_source'];
            $ttd_signature_data = $_POST['ttd_signature'];
            
            $ttd_position_x = (float)$_POST['ttd_position_x'];
            $ttd_position_y = (float)$_POST['ttd_position_y'];
            $catatan = mysqli_real_escape_string($mysqli, $_POST['catatan_persetujuan']);
            
            $ttd_filename_relative = '';
            $ttd_filename_absolute = '';

            if ($ttd_source === 'saved') {
                $ttd_filename_relative = $ttd_signature_data;
                $ttd_filename_absolute = $project_root . $ttd_filename_relative;
                if (!file_exists($ttd_filename_absolute)) {
                    echo "<script>alert('Error: File tanda tangan dari riwayat tidak ditemukan.');</script>";
                    exit;
                }
            } else {
                $ttd_filename_relative = 'modules/dokumen/ttd/' . $id_pengajuan . '_' . time() . '.png';
                $ttd_filename_absolute = $project_root . $ttd_filename_relative;
                
                $ttd_data_clean = str_replace('data:image/png;base64,', '', $ttd_signature_data);
                $ttd_data_clean = str_replace(' ', '+', $ttd_data_clean);
                
                if (!file_put_contents($ttd_filename_absolute, base64_decode($ttd_data_clean))) {
                    echo "<script>alert('Error saat menyimpan file tanda tangan.');</script>";
                    exit;
                }
            }
            
            if (strtolower(pathinfo($data['file_dokumen'], PATHINFO_EXTENSION)) !== 'pdf') {
                echo "<script>alert('Error: Hanya file PDF yang dapat ditandatangani.');</script>";
                exit;
            }

            $original_pdf_absolute = $project_root . $data['file_dokumen'];
            $signed_filename_relative = 'modules/dokumen/signed/' . 'signed_' . $id_pengajuan . '_' . time() . '.pdf';
            $signed_filename_absolute = $project_root . $signed_filename_relative;
            
            $mergeResult = mergeSignatureWithPDF($original_pdf_absolute, $ttd_filename_absolute, $ttd_position_x, $ttd_position_y, $signed_filename_absolute);
            
            if ($ttd_source !== 'saved' && file_exists($ttd_filename_absolute)) {
                unlink($ttd_filename_absolute);
            }

            if (!$mergeResult['success']) {
                echo "<script>alert('Gagal menandatangani dokumen: " . addslashes($mergeResult['message']) . "');</script>";
                exit;
            }

            // Pass page dimensions back to client for verification (via hidden input or JS)
            echo "<script>
                document.getElementById('hiddenPageWidth').value = '{$mergeResult['page_width']}';
                document.getElementById('hiddenPageHeight').value = '{$mergeResult['page_height']}';
            </script>";

            $update_query = "UPDATE tbl_pengajuan SET 
                        status_pengajuan = 'Disetujui', 
                        catatan_pimpinan = ?,
                        id_penandatangan = ?,
                        tanggal_ttd = NOW(),
                        file_ttd = ?,
                        file_dokumen_signed = ?,
                        updated_at = NOW()
                        WHERE id_pengajuan = ?";
            
            $stmt_update = mysqli_prepare($mysqli, $update_query);
            mysqli_stmt_bind_param($stmt_update, "sissi", 
                $catatan, 
                $_SESSION['id_user'], 
                $ttd_filename_relative,
                $signed_filename_relative,
                $id_pengajuan
            );
            
            if (mysqli_stmt_execute($stmt_update)) {
                echo "<script>
                    alert('Pengajuan berhasil disetujui dan ditandatangani.');
                    window.location.href = '?module=antrian_surat';
                </script>";
            } else {
                echo "<script>alert('Error saat update database: " . mysqli_error($mysqli) . "');</script>";
            }
            exit;
        }
    }
}
?>

<div class="panel-header">
    <div class="page-inner py-4">
        <div class="d-flex align-items-left align-items-md-top flex-column flex-md-row">
            <div class="page-header">
                <h4 class="page-title"><i class="fas fa-signature mr-2"></i> Detail Antrian Tanda Tangan</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home"><a href="?module=beranda"><i class="flaticon-home"></i></a></li>
                    <li class="separator"><i class="flaticon-right-arrow"></i></li>
                    <li class="nav-item"><a href="?module=antrian_surat">Antrian Pengajuan</a></li>
                    <li class="separator"><i class="flaticon-right-arrow"></i></li>
                    <li class="nav-item"><a>Detail Pengajuan</a></li>
                </ul>
            </div>
            <div class="ml-md-auto py-2 py-md-0">
                <a href="?module=antrian_surat" class="btn btn-secondary btn-round">
                    <span class="btn-label"><i class="fa fa-arrow-left mr-2"></i></span> Kembali
                </a>
            </div>
        </div>
    </div>
</div>

<div class="page-inner mt--5">
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h5 class="card-title mb-0"><i class="fas fa-file-alt mr-2"></i>Detail Pengajuan</h5>
                        <div class="ml-auto">
                            <span class="badge <?php echo ($days_waiting >= 7) ? 'badge-danger' : (($days_waiting >= 3) ? 'badge-warning' : 'badge-success'); ?>">
                                <?php echo ($days_waiting >= 7) ? 'Urgent' : (($days_waiting >= 3) ? 'Tinggi' : 'Normal'); ?>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr><td width="40%"><strong>Jenis:</strong></td><td><?php echo htmlspecialchars($data['nama_jenis']); ?></td></tr>
                                <tr><td><strong>Judul:</strong></td><td><?php echo htmlspecialchars($data['judul_surat']); ?></td></tr>
                                <tr><td><strong>No. Surat:</strong></td><td><?php echo htmlspecialchars($data['nomor_surat'] ?: '-'); ?></td></tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr><td width="40%"><strong>Pengaju:</strong></td><td><?php echo htmlspecialchars($data['nama_pengaju']); ?></td></tr>
                                <tr><td><strong>Tgl. Masuk:</strong></td><td><?php echo date('d/m/Y H:i', strtotime($data['tanggal_pengajuan'])); ?></td></tr>
                                <tr><td><strong>Menunggu:</strong></td><td><?php echo ceil($days_waiting); ?> hari</td></tr>
                            </table>
                        </div>
                    </div>
                    <?php if (!empty($data['perihal'])): ?>
                        <div class="mt-3">
                            <strong>Perihal:</strong>
                            <div class="bg-light p-3 mt-2 rounded"><?php echo nl2br(htmlspecialchars($data['perihal'])); ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-header">
                    <h5 class="card-title mb-0"><i class="fas fa-file-pdf mr-2"></i>Preview Dokumen</h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($data['file_dokumen']) && file_exists($data['file_dokumen'])): ?>
                        <div id="documentContainer" style="position: relative; border: 1px solid #ddd; min-height: 600px; background: #f8f9fa; overflow: hidden;">
                            <iframe id="pdfIframe" src="<?php echo $data['file_dokumen']; ?>#toolbar=0" width="100%" height="600px" style="border: none; display: block;"></iframe>
                            <div id="signaturePlaceholder" style="position: absolute; width: 132px; height: 66px; border: 2px dashed #007bff; background: rgba(0,123,255,0.2); display: none; cursor: move; z-index: 1000; top: 50px; left: 50px;">
                                <div style="text-align: center; line-height: 66px; font-size: 12px; color: #007bff; font-weight: bold; pointer-events: none;">
                                    Tanda Tangan
                                </div>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="button" class="btn btn-primary" id="placementButton">
                                <i class="fas fa-signature mr-2"></i>Tentukan Posisi Tanda Tangan
                            </button>
                            <a href="<?php echo $data['file_dokumen']; ?>" target="_blank" class="btn btn-outline-primary">
                                <i class="fas fa-external-link-alt mr-2"></i>Buka di Tab Baru
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-3">
                            <i class="fas fa-file-times fa-3x text-muted mb-3"></i>
                            <h5>Dokumen tidak tersedia</h5>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0"><i class="fas fa-pen-fancy mr-2"></i>Tanda Tangan Digital</h5>
                </div>
                <div class="card-body">
                    <ul class="nav nav-pills nav-fill mb-3" id="signatureTabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="draw-tab" data-toggle="tab" href="#draw" role="tab">
                                <i class="fas fa-pen mr-1"></i>Gambar
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="upload-tab" data-toggle="tab" href="#upload" role="tab">
                                <i class="fas fa-upload mr-1"></i>Upload
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="saved-tab" data-toggle="tab" href="#saved" role="tab">
                                <i class="fas fa-history mr-1"></i>Riwayat
                            </a>
                        </li>
                    </ul>

                    <div class="tab-content" id="signatureTabContent">
                        <!-- Tab Gambar -->
                        <div class="tab-pane fade show active" id="draw" role="tabpanel">
                            <div class="text-center mb-3">
                                <canvas id="signatureCanvas" width="280" height="150" 
                                        style="border: 1px solid #ddd; background: white; cursor: crosshair; touch-action: none;">
                                </canvas>
                            </div>
                            <div class="text-center">
                                <button type="button" class="btn btn-sm btn-secondary" onclick="clearSignature()">
                                    <i class="fas fa-eraser mr-1"></i>Hapus
                                </button>
                            </div>
                        </div>

                        <!-- Tab Upload -->
                        <div class="tab-pane fade" id="upload" role="tabpanel">
                            <div class="form-group">
                                <label>Upload Gambar Tanda Tangan</label>
                                <input type="file" class="form-control-file" id="signatureFile" accept="image/png,image/jpeg">
                                <small class="text-muted">Format: PNG, JPG (Max: 2MB)</small>
                            </div>
                            <div id="uploadPreview" class="text-center" style="display: none;">
                                <img id="uploadedSignature" style="max-width: 200px; max-height: 100px; border: 1px solid #ddd;">
                            </div>
                        </div>

                        <!-- Tab Riwayat -->
                        <div class="tab-pane fade" id="saved" role="tabpanel">
                            <p class="text-muted small mb-3">Pilih TTD yang pernah digunakan:</p>
                            <div class="row">
                                <?php if (!empty($riwayat_ttd)): ?>
                                    <?php foreach ($riwayat_ttd as $index => $ttd_path): ?>
                                        <div class="col-6 mb-2">
                                            <img src="<?php echo htmlspecialchars($ttd_path); ?>" 
                                                 class="img-fluid border rounded p-1 saved-signature" 
                                                 style="cursor: pointer; max-height: 60px; width: 100%; object-fit: contain;" 
                                                 data-path="<?php echo htmlspecialchars($ttd_path); ?>" 
                                                 data-index="<?php echo $index; ?>"
                                                 alt="Riwayat TTD">
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="col-12 text-center">
                                        <p class="small text-muted">Tidak ada riwayat tanda tangan.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Preview Tanda Tangan -->
                    <div id="signaturePreview" class="mt-3" style="display: none;">
                        <h6>Preview:</h6>
                        <div class="text-center p-2 border rounded bg-light">
                            <img id="finalSignature" style="max-width: 150px; max-height: 75px;">
                        </div>
                    </div>
                    
                    <!-- Catatan Pimpinan -->
                    <div class="mt-3 form-group">
                        <label for="catatanPimpinan">Catatan Pimpinan</label>
                        <textarea class="form-control" id="catatanPimpinan" rows="3" placeholder="Berikan catatan..."></textarea>
                    </div>

                    <!-- Tombol Aksi -->
                    <div class="mt-4">
                        <button type="button" class="btn btn-success btn-block" id="btnSetujui" disabled>
                            <i class="fas fa-check mr-2"></i>Setujui & Tanda Tangani
                        </button>
                        <button type="button" class="btn btn-danger btn-block mt-2" data-toggle="modal" data-target="#modalReject">
                            <i class="fas fa-times mr-2"></i>Tolak Pengajuan
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tolak -->
<div class="modal fade" id="modalReject" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-exclamation-triangle mr-2 text-warning"></i>Tolak Pengajuan
                </h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <strong>Peringatan!</strong> Tindakan ini tidak dapat dibatalkan.
                    </div>
                    <div class="form-group">
                        <label>Alasan Penolakan <span class="text-danger">*</span></label>
                        <textarea class="form-control" name="catatan_penolakan" rows="4" required 
                                  placeholder="Jelaskan alasan penolakan..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" name="action" value="tolak" class="btn btn-danger">Tolak</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Form Hidden untuk Submit -->
<form id="approvalForm" method="POST" style="display: none;">
    <input type="hidden" name="action" value="setujui">
    <input type="hidden" name="ttd_source" id="hiddenSignatureSource" value="draw">
    <input type="hidden" name="ttd_signature" id="hiddenSignature">
    <input type="hidden" name="ttd_position_x" id="hiddenPositionX" value="50">
    <input type="hidden" name="ttd_position_y" id="hiddenPositionY" value="50">
    <input type="hidden" name="catatan_persetujuan" id="hiddenCatatan">
    <input type="hidden" id="hiddenPageWidth" value="210">
    <input type="hidden" id="hiddenPageHeight" value="297">
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing signature system...');
    
    // =================================================================
    // VARIABEL DAN ELEMEN PENTING
    // =================================================================
    const canvas = document.getElementById('signatureCanvas');
    const ctx = canvas.getContext('2d');
    const btnSetujui = document.getElementById('btnSetujui');
    const placeholder = document.getElementById('signaturePlaceholder');
    const docContainer = document.getElementById('documentContainer');
    const pdfIframe = document.getElementById('pdfIframe');
    const placementButton = document.getElementById('placementButton');
    const signatureFileInput = document.getElementById('signatureFile');
    const savedSignatureImages = document.querySelectorAll('.saved-signature');

    let isDrawing = false;
    let signatureData = null;
    let currentSignatureSource = 'draw';
    let isPlacementMode = false;
    let pdfDimensions = null;
    let iframeDimensions = null;

    // Konstanta ukuran TTD (dalam mm)
    const SIGNATURE_WIDTH_MM = 50;
    const SIGNATURE_HEIGHT_MM = 25;

    // =================================================================
    // FUNGSI UNTUK MENDAPATKAN DIMENSI PDF YANG AKURAT
    // =================================================================
    function detectPdfDimensions() {
        // Default A4 dimensions in mm
        let pageWidth = 210;
        let pageHeight = 297;
        
        // Try to get dimensions from PHP (if available after merge)
        const hiddenWidth = document.getElementById('hiddenPageWidth');
        const hiddenHeight = document.getElementById('hiddenPageHeight');
        
        if (hiddenWidth && hiddenHeight) {
            const width = parseFloat(hiddenWidth.value);
            const height = parseFloat(hiddenHeight.value);
            if (width > 0 && height > 0) {
                pageWidth = width;
                pageHeight = height;
            }
        }
        
        pdfDimensions = {
            width: pageWidth,
            height: pageHeight
        };
        
        console.log('PDF dimensions detected:', pdfDimensions);
        return pdfDimensions;
    }

    function getIframeDimensions() {
        const rect = pdfIframe.getBoundingClientRect();
        iframeDimensions = {
            width: rect.width,
            height: rect.height
        };
        console.log('Iframe dimensions:', iframeDimensions);
        return iframeDimensions;
    }

    // =================================================================
    // FUNGSI KONVERSI KOORDINAT YANG DIPERBAIKI
    // =================================================================
    function pixelToMm(pixelX, pixelY) {
        if (!pdfDimensions || !iframeDimensions) {
            detectPdfDimensions();
            getIframeDimensions();
        }
        
        // Konversi pixel ke rasio (0-1)
        const ratioX = pixelX / iframeDimensions.width;
        const ratioY = pixelY / iframeDimensions.height;
        
        // Konversi rasio ke mm
        const mmX = ratioX * pdfDimensions.width;
        // Untuk Y: konversi dari top-left ke bottom-left origin
        const mmY = pdfDimensions.height - (ratioY * pdfDimensions.height) - SIGNATURE_HEIGHT_MM;
        
        // Pastikan dalam batas halaman
        const constrainedX = Math.max(0, Math.min(mmX, pdfDimensions.width - SIGNATURE_WIDTH_MM));
        const constrainedY = Math.max(0, Math.min(mmY, pdfDimensions.height - SIGNATURE_HEIGHT_MM));
        
        console.log('Pixel to MM conversion:', {
            input: { pixelX, pixelY },
            ratios: { ratioX: ratioX.toFixed(3), ratioY: ratioY.toFixed(3) },
            mmRaw: { mmX: mmX.toFixed(2), mmY: mmY.toFixed(2) },
            mmConstrained: { x: constrainedX.toFixed(2), y: constrainedY.toFixed(2) }
        });
        
        return { x: constrainedX, y: constrainedY };
    }

    function mmToPixel(mmX, mmY) {
        if (!pdfDimensions || !iframeDimensions) {
            detectPdfDimensions();
            getIframeDimensions();
        }
        
        // Konversi mm ke rasio (0-1)
        const ratioX = mmX / pdfDimensions.width;
        // Untuk Y: konversi dari bottom-left ke top-left origin
        const ratioY = (pdfDimensions.height - mmY - SIGNATURE_HEIGHT_MM) / pdfDimensions.height;
        
        // Konversi rasio ke pixel
        const pixelX = ratioX * iframeDimensions.width;
        const pixelY = ratioY * iframeDimensions.height;
        
        console.log('MM to Pixel conversion:', {
            input: { mmX, mmY },
            ratios: { ratioX: ratioX.toFixed(3), ratioY: ratioY.toFixed(3) },
            output: { pixelX: pixelX.toFixed(2), pixelY: pixelY.toFixed(2) }
        });
        
        return { x: pixelX, y: pixelY };
    }

    // =================================================================
    // FUNGSI UTILITAS
    // =================================================================
    function updateButtonState() {
        const hasSignature = signatureData && signatureData.trim() !== '';
        btnSetujui.disabled = !hasSignature;
        console.log('Button state updated:', hasSignature ? 'enabled' : 'disabled');
    }

    function showPreview(data, source = null) {
        console.log('Showing preview for source:', source || currentSignatureSource);
        signatureData = data;
        
        if (source) {
            currentSignatureSource = source;
            document.getElementById('hiddenSignatureSource').value = source;
        }
        
        document.getElementById('finalSignature').src = data;
        document.getElementById('signaturePreview').style.display = 'block';
        updateButtonState();
    }
    
    function resetAllSignatureInputs() {
        console.log('Resetting all signature inputs...');
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (signatureFileInput) {
            signatureFileInput.value = '';
        }
        document.getElementById('uploadPreview').style.display = 'none';
        savedSignatureImages.forEach(img => {
            img.classList.remove('border-primary', 'shadow', 'selected');
        });
        
        document.getElementById('signaturePreview').style.display = 'none';
        signatureData = null;
        updateButtonState();
    }

    function updateHiddenPositions(xMm, yMm) {
        document.getElementById('hiddenPositionX').value = xMm.toFixed(2);
        document.getElementById('hiddenPositionY').value = yMm.toFixed(2);
        console.log('Updated position values (mm):', xMm.toFixed(2), yMm.toFixed(2));
    }

    window.clearSignature = function() {
        console.log('Clearing signature canvas...');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (currentSignatureSource === 'draw') {
            document.getElementById('signaturePreview').style.display = 'none';
            signatureData = null;
            updateButtonState();
        }
    };

    // =================================================================
    // LOGIKA PENEMPATAN TANDA TANGAN YANG DIPERBAIKI
    // =================================================================
    if (placementButton && docContainer && placeholder && pdfIframe) {
        // Initialize dimensions
        pdfIframe.addEventListener('load', function() {
            setTimeout(() => {
                detectPdfDimensions();
                getIframeDimensions();
                // Set initial position in center-bottom
                const centerX = pdfDimensions.width / 2 - SIGNATURE_WIDTH_MM / 2;
                const bottomY = 30; // 30mm from bottom
                const pixelPos = mmToPixel(centerX, bottomY);
                placeholder.style.left = pixelPos.x + 'px';
                placeholder.style.top = pixelPos.y + 'px';
                updateHiddenPositions(centerX, bottomY);
            }, 500);
        });

        // Recalculate on window resize
        window.addEventListener('resize', function() {
            setTimeout(() => {
                getIframeDimensions();
                // Reposition placeholder based on current mm values
                const currentX = parseFloat(document.getElementById('hiddenPositionX').value) || 50;
                const currentY = parseFloat(document.getElementById('hiddenPositionY').value) || 50;
                const pixelPos = mmToPixel(currentX, currentY);
                placeholder.style.left = pixelPos.x + 'px';
                placeholder.style.top = pixelPos.y + 'px';
            }, 100);
        });

        placementButton.addEventListener('click', function() {
            console.log('Placement button clicked');
            
            if (isPlacementMode) {
                exitPlacementMode();
                return;
            }
            
            isPlacementMode = true;
            docContainer.style.cursor = 'crosshair';
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-mouse-pointer mr-2"></i>Klik pada Dokumen untuk Menempatkan TTD';
            
            // Ensure dimensions are current
            detectPdfDimensions();
            getIframeDimensions();
            
            if (placeholder.style.display === 'none') {
                placeholder.style.display = 'block';
                // Set to center-bottom if not positioned yet
                const centerX = pdfDimensions.width / 2 - SIGNATURE_WIDTH_MM / 2;
                const bottomY = 30;
                const pixelPos = mmToPixel(centerX, bottomY);
                placeholder.style.left = pixelPos.x + 'px';
                placeholder.style.top = pixelPos.y + 'px';
                updateHiddenPositions(centerX, bottomY);
            }
            
            const clickHandler = function(event) {
                if (!isPlacementMode) return;
                
                // Get current dimensions
                getIframeDimensions();
                
                const containerRect = docContainer.getBoundingClientRect();
                const iframeRect = pdfIframe.getBoundingClientRect();
                
                // Calculate position relative to iframe
                let xPx = event.clientX - iframeRect.left;
                let yPx = event.clientY - iframeRect.top;
                
                // Ensure click is within iframe bounds
                if (xPx < 0 || xPx > iframeDimensions.width || yPx < 0 || yPx > iframeDimensions.height) {
                    console.log('Click outside iframe bounds, ignoring');
                    return;
                }
                
                // Convert to mm coordinates
                const mmPos = pixelToMm(xPx, yPx);
                
                // Convert back to pixel for visual placement
                const finalPixelPos = mmToPixel(mmPos.x, mmPos.y);
                
                console.log('Placing signature:', {
                    clickPixel: { x: xPx.toFixed(2), y: yPx.toFixed(2) },
                    mmPosition: { x: mmPos.x.toFixed(2), y: mmPos.y.toFixed(2) },
                    finalPixel: { x: finalPixelPos.x.toFixed(2), y: finalPixelPos.y.toFixed(2) }
                });
                
                placeholder.style.left = finalPixelPos.x + 'px';
                placeholder.style.top = finalPixelPos.y + 'px';
                placeholder.style.display = 'block';
                
                updateHiddenPositions(mmPos.x, mmPos.y);
                exitPlacementMode();
                
                docContainer.removeEventListener('click', clickHandler);
            };
            
            docContainer.addEventListener('click', clickHandler);
        });
        
        function exitPlacementMode() {
            isPlacementMode = false;
            docContainer.style.cursor = 'default';
            placementButton.disabled = false;
            placementButton.innerHTML = '<i class="fas fa-signature mr-2"></i>Tentukan Posisi Tanda Tangan';
        }

        // Make placeholder draggable with improved calculations
        makeDraggable(placeholder);
        
        function makeDraggable(element) {
            let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
            
            element.addEventListener('mousedown', function(e) {
                e.preventDefault();
                console.log('Starting drag...');
                pos3 = e.clientX;
                pos4 = e.clientY;
                
                // Ensure current dimensions
                getIframeDimensions();
                
                document.addEventListener('mouseup', closeDragElement);
                document.addEventListener('mousemove', elementDrag);
            });
            
            function elementDrag(e) {
                e.preventDefault();
                pos1 = pos3 - e.clientX;
                pos2 = pos4 - e.clientY;
                pos3 = e.clientX;
                pos4 = e.clientY;
                
                let newTop = element.offsetTop - pos2;
                let newLeft = element.offsetLeft - pos1;
                
                // Constrain within iframe bounds
                newLeft = Math.max(0, Math.min(newLeft, iframeDimensions.width - element.offsetWidth));
                newTop = Math.max(0, Math.min(newTop, iframeDimensions.height - element.offsetHeight));
                
                element.style.top = newTop + "px";
                element.style.left = newLeft + "px";
                
                // Convert to mm coordinates for storage
                const mmPos = pixelToMm(newLeft, newTop);
                updateHiddenPositions(mmPos.x, mmPos.y);
            }
            
            function closeDragElement() {
                console.log('Drag ended');
                document.removeEventListener('mouseup', closeDragElement);
                document.removeEventListener('mousemove', elementDrag);
            }
        }
    }
    
    // =================================================================
    // LOGIKA TAB TANDA TANGAN (unchanged)
    // =================================================================
    if (canvas && ctx) {
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        
        canvas.addEventListener('mousedown', function(e) {
            isDrawing = true;
            ctx.beginPath();
            const rect = canvas.getBoundingClientRect();
            ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
        });
        
        canvas.addEventListener('mousemove', function(e) {
            if (!isDrawing) return;
            const rect = canvas.getBoundingClientRect();
            ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
            ctx.stroke();
        });
        
        const stopDrawing = function() {
            if (isDrawing) {
                isDrawing = false;
                if (currentSignatureSource === 'draw') {
                    const imageData = canvas.toDataURL('image/png');
                    if (imageData !== 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==') {
                        showPreview(imageData, 'draw');
                    }
                }
            }
        };
        
        canvas.addEventListener('mouseup', stopDrawing);
        canvas.addEventListener('mouseout', stopDrawing);
        
        // Touch events
        canvas.addEventListener('touchstart', function(e) {
            e.preventDefault();
            const touch = e.touches[0];
            const rect = canvas.getBoundingClientRect();
            isDrawing = true;
            ctx.beginPath();
            ctx.moveTo(touch.clientX - rect.left, touch.clientY - rect.top);
        });
        
        canvas.addEventListener('touchmove', function(e) {
            e.preventDefault();
            if (!isDrawing) return;
            const touch = e.touches[0];
            const rect = canvas.getBoundingClientRect();
            ctx.lineTo(touch.clientX - rect.left, touch.clientY - rect.top);
            ctx.stroke();
        });
        
        canvas.addEventListener('touchend', function(e) {
            e.preventDefault();
            stopDrawing();
        });
    }

    // File upload handler
    if (signatureFileInput) {
        signatureFileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                console.log('File selected:', file.name);
                
                if (file.size > 2 * 1024 * 1024) {
                    alert('File terlalu besar! Maksimal 2MB.');
                    this.value = '';
                    return;
                }
                
                if (!file.type.match(/^image\/(png|jpeg|jpg)$/)) {
                    alert('Format file tidak didukung! Gunakan PNG atau JPG.');
                    this.value = '';
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    console.log('File loaded successfully');
                    document.getElementById('uploadedSignature').src = e.target.result;
                    document.getElementById('uploadPreview').style.display = 'block';
                    showPreview(e.target.result, 'upload');
                };
                reader.onerror = function() {
                    alert('Error membaca file!');
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // Saved signatures handler
    if (savedSignatureImages.length > 0) {
        console.log('Found', savedSignatureImages.length, 'saved signatures');
        
        savedSignatureImages.forEach(function(img, index) {
            img.addEventListener('click', function() {
                console.log('Saved signature clicked:', this.dataset.path);
                
                savedSignatureImages.forEach(function(otherImg) {
                    otherImg.classList.remove('border-primary', 'shadow', 'selected');
                });
                
                this.classList.add('border-primary', 'shadow', 'selected');
                
                showPreview(this.dataset.path, 'saved');
            });
            
            img.addEventListener('error', function() {
                console.warn('Failed to load saved signature:', this.dataset.path);
                this.style.display = 'none';
            });
        });
    }

    // Tab switching handler
    const tabLinks = document.querySelectorAll('a[data-toggle="tab"]');
    tabLinks.forEach(function(tabLink) {
        tabLink.addEventListener('shown.bs.tab', function(e) {
            const targetId = e.target.getAttribute('href').substring(1);
            currentSignatureSource = targetId;
            document.getElementById('hiddenSignatureSource').value = targetId;
            
            console.log('Tab switched to:', targetId);
            
            if (targetId !== 'saved') {
                resetAllSignatureInputs();
            }
        });
    });

    // Approval button handler
    if (btnSetujui) {
        btnSetujui.addEventListener('click', function() {
            if (this.disabled) {
                console.warn('Button is disabled, ignoring click');
                return;
            }
            
            if (!signatureData) {
                alert('Silakan buat, upload, atau pilih tanda tangan terlebih dahulu!');
                return;
            }
            
            const posX = document.getElementById('hiddenPositionX').value;
            const posY = document.getElementById('hiddenPositionY').value;
            if (!posX || !posY) {
                alert('Silakan tentukan posisi tanda tangan terlebih dahulu!');
                return;
            }
            
            if (confirm('Anda yakin ingin menyetujui dan menandatangani pengajuan ini?')) {
                console.log('Submitting approval with:', {
                    source: currentSignatureSource,
                    hasSignature: !!signatureData,
                    position: { x: posX, y: posY }
                });
                
                document.getElementById('hiddenSignature').value = signatureData;
                document.getElementById('hiddenCatatan').value = document.getElementById('catatanPimpinan').value;
                document.getElementById('hiddenSignatureSource').value = currentSignatureSource;
                
                this.disabled = true;
                this.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Memproses...';
                
                document.getElementById('approvalForm').submit();
            }
        });
    }

    console.log('Signature system initialized successfully');
    updateButtonState();
    
    // Initialize placeholder position
    if (placeholder) {
        placeholder.style.display = 'block';
        // Will be properly positioned after iframe loads
    }
});
</script>

<style>
#signatureCanvas { 
    touch-action: none; 
    display: block;
    margin: 0 auto;
}

.saved-signature {
    transition: all 0.2s ease;
}

.saved-signature:hover {
    transform: scale(1.05);
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
}

.saved-signature.border-primary { 
    border-width: 3px !important;
    box-shadow: 0 0 0 2px rgba(0,123,255,0.25);
}

.saved-signature.selected {
    background-color: rgba(0,123,255,0.1);
}

.btn:disabled { 
    opacity: 0.65; 
    cursor: not-allowed; 
}

/* Placeholder tanda tangan yang diperbaiki */
#signaturePlaceholder {
    position: absolute;
    user-select: none;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    width: 132px; /* 50mm converted to pixels at 96 DPI */
    height: 66px; /* 25mm converted to pixels at 96 DPI */
    border: 2px dashed #007bff;
    background: rgba(0,123,255,0.2);
    cursor: move;
    z-index: 1000;
    box-sizing: border-box;
    border-radius: 4px;
    backdrop-filter: blur(1px);
}

#signaturePlaceholder:hover {
    background: rgba(0,123,255,0.3);
    border-color: #0056b3;
    border-width: 3px;
}

#signaturePlaceholder:active {
    background: rgba(0,123,255,0.4);
    cursor: grabbing;
}

#signaturePlaceholder .placeholder-text {
    text-align: center;
    line-height: 62px; /* Adjust for border */
    font-size: 11px;
    color: #007bff;
    font-weight: bold;
    pointer-events: none;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 0 4px;
}

/* Container dokumen yang diperbaiki */
#documentContainer {
    position: relative;
    overflow: visible;
    border: 1px solid #ddd;
    border-radius: 4px;
    background: #f8f9fa;
}

#documentContainer.placement-mode {
    cursor: crosshair !important;
}

#pdfIframe {
    border: none;
    display: block;
    width: 100%;
    height: 600px;
    border-radius: 4px;
}

/* Tab navigation yang diperbaiki */
.nav-pills .nav-link {
    border-radius: 0.375rem;
    font-size: 0.875rem;
    padding: 0.5rem 0.75rem;
    transition: all 0.2s ease;
}

.nav-pills .nav-link:hover {
    background-color: rgba(0,123,255,0.1);
}

.nav-pills .nav-link.active {
    background-color: #007bff;
    border-color: #007bff;
    color: white;
}

.tab-content {
    min-height: 200px;
    padding-top: 1rem;
}

/* Preview tanda tangan */
#signaturePreview {
    border-top: 1px solid #dee2e6;
    padding-top: 1rem;
    margin-top: 1rem;
}

#signaturePreview .preview-container {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 4px;
    padding: 1rem;
    text-align: center;
}

#finalSignature {
    max-width: 150px;
    max-height: 75px;
    border: 1px solid #dee2e6;
    border-radius: 2px;
    background: white;
}

/* Upload preview */
#uploadPreview {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 4px;
    padding: 1rem;
    margin-top: 1rem;
}

#uploadedSignature {
    max-width: 200px;
    max-height: 100px;
    border: 1px solid #ddd;
    border-radius: 2px;
}

/* Modal styling */
.modal-content {
    border-radius: 0.5rem;
    border: none;
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.modal-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #dee2e6;
    border-radius: 0.5rem 0.5rem 0 0;
}

.modal-footer {
    background-color: #f8f9fa;
    border-top: 1px solid #dee2e6;
    border-radius: 0 0 0.5rem 0.5rem;
}

/* Alert styling */
.alert {
    border-radius: 0.375rem;
    border: none;
    font-size: 0.875rem;
}

.alert-warning {
    background-color: #fff3cd;
    color: #856404;
    border-left: 4px solid #ffc107;
}

/* Button improvements */
.btn {
    border-radius: 0.375rem;
    font-weight: 500;
    transition: all 0.2s ease;
}

.btn:focus,
.btn.focus {
    box-shadow: 0 0 0 0.2rem rgba(0,123,255,0.25);
}

.btn-success {
    background-color: #28a745;
    border-color: #28a745;
}

.btn-success:hover {
    background-color: #218838;
    border-color: #1e7e34;
    transform: translateY(-1px);
}

.btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
}

.btn-danger:hover {
    background-color: #c82333;
    border-color: #bd2130;
    transform: translateY(-1px);
}

.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
}

.btn-primary:hover {
    background-color: #0069d9;
    border-color: #0062cc;
    transform: translateY(-1px);
}

.btn-secondary {
    background-color: #6c757d;
    border-color: #6c757d;
}

.btn-secondary:hover {
    background-color: #5a6268;
    border-color: #545b62;
    transform: translateY(-1px);
}

/* Form controls */
.form-control {
    border-radius: 0.375rem;
    border: 1px solid #ced4da;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.form-control:focus {
    border-color: #80bdff;
    box-shadow: 0 0 0 0.2rem rgba(0,123,255,0.25);
}

.form-control-file {
    border-radius: 0.375rem;
    padding: 0.375rem 0.75rem;
    border: 1px solid #ced4da;
    background-color: #fff;
    transition: border-color 0.15s ease-in-out;
}

.form-control-file:focus {
    border-color: #80bdff;
    outline: 0;
    box-shadow: 0 0 0 0.2rem rgba(0,123,255,0.25);
}

/* Card improvements */
.card {
    border: none;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    border-radius: 0.5rem;
}

.card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #dee2e6;
    border-radius: 0.5rem 0.5rem 0 0;
    padding: 1rem 1.25rem;
}

.card-body {
    padding: 1.25rem;
}

/* Badge improvements */
.badge {
    font-size: 0.75em;
    font-weight: 600;
    border-radius: 0.25rem;
    padding: 0.375em 0.75em;
}

.badge-success {
    background-color: #28a745;
}

.badge-warning {
    background-color: #ffc107;
    color: #212529;
}

.badge-danger {
    background-color: #dc3545;
}

/* Table improvements */
.table-borderless td {
    border: none;
    padding: 0.5rem 0;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    #signaturePlaceholder {
        width: 100px;
        height: 50px;
    }
    
    #signaturePlaceholder .placeholder-text {
        font-size: 9px;
        line-height: 46px;
    }
    
    .nav-pills .nav-link {
        padding: 0.375rem 0.5rem;
        font-size: 0.8rem;
    }
    
    #pdfIframe {
        height: 400px;
    }
    
    .btn-block {
        font-size: 0.875rem;
        padding: 0.5rem 1rem;
    }
}

/* Loading states */
.btn.loading {
    position: relative;
    color: transparent;
}

.btn.loading::after {
    content: "";
    position: absolute;
    width: 16px;
    height: 16px;
    top: 50%;
    left: 50%;
    margin-left: -8px;
    margin-top: -8px;
    border: 2px solid transparent;
    border-top-color: currentColor;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style>