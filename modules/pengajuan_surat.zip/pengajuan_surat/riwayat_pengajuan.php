<?php
// Prevent direct access
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    header('location: ../../404.html');
    exit;
}

// Start session if not already started
if (!isset($_SESSION)) {
    session_start();
}

// Debug: Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check access rights
if (!isset($_SESSION['hak_akses']) || !in_array($_SESSION['hak_akses'], ['SuperAdmin', 'Pimpinan', 'SekretarisPimpinan'])) {
    echo "<script>alert('Akses ditolak! Hak akses: " . ($_SESSION['hak_akses'] ?? 'tidak ada') . "');</script>";
    header('location: ?module=login');
    exit;
}

// Check database connection
if (!isset($mysqli)) {
    die("Koneksi database tidak tersedia. Pastikan file koneksi sudah di-include.");
}

// Ambil parameter untuk filter dan pencarian
$search = isset($_GET['search']) ? mysqli_real_escape_string($mysqli, $_GET['search']) : '';
$jenis_filter = isset($_GET['jenis']) ? (int)$_GET['jenis'] : 0;
$bulan_filter = isset($_GET['bulan']) ? mysqli_real_escape_string($mysqli, $_GET['bulan']) : '';
$tahun_filter = isset($_GET['tahun']) ? (int)$_GET['tahun'] : 0;

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Query untuk menghitung total data
$count_query = "SELECT COUNT(*) as total FROM tbl_pengajuan p 
                INNER JOIN tbl_jenis j ON p.jenis_dokumen = j.id_jenis 
                INNER JOIN tbl_user u ON p.id_pengaju = u.id_user 
                WHERE p.status_pengajuan = 'Disetujui'";

$where_conditions = [];
if (!empty($search)) {
    $where_conditions[] = "(p.judul_surat LIKE '%$search%' OR p.perihal LIKE '%$search%' OR p.nomor_surat LIKE '%$search%' OR u.nama_user LIKE '%$search%')";
}
if ($jenis_filter > 0) {
    $where_conditions[] = "p.jenis_dokumen = $jenis_filter";
}
if (!empty($bulan_filter)) {
    $where_conditions[] = "DATE_FORMAT(p.tanggal_ttd, '%Y-%m') = '$bulan_filter'";
}
if ($tahun_filter > 0) {
    $where_conditions[] = "YEAR(p.tanggal_ttd) = $tahun_filter";
}

if (!empty($where_conditions)) {
    $count_query .= " AND " . implode(" AND ", $where_conditions);
}

$count_result = mysqli_query($mysqli, $count_query);
$total_data = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_data / $limit);

// Query untuk mengambil data riwayat
$query = "SELECT p.*, j.nama_jenis, u.nama_user as nama_pengaju
          FROM tbl_pengajuan p 
          INNER JOIN tbl_jenis j ON p.jenis_dokumen = j.id_jenis 
          INNER JOIN tbl_user u ON p.id_pengaju = u.id_user 
          WHERE p.status_pengajuan = 'Disetujui'";

if (!empty($where_conditions)) {
    $query .= " AND " . implode(" AND ", $where_conditions);
}

$query .= " ORDER BY p.tanggal_ttd DESC LIMIT $offset, $limit";
$result = mysqli_query($mysqli, $query);

// Ambil data untuk filter
$query_jenis = mysqli_query($mysqli, "SELECT * FROM tbl_jenis ORDER BY nama_jenis ASC");
$query_bulan = mysqli_query($mysqli, "SELECT DISTINCT DATE_FORMAT(tanggal_ttd, '%Y-%m') as bulan FROM tbl_pengajuan WHERE status_pengajuan = 'Disetujui' AND tanggal_ttd IS NOT NULL ORDER BY bulan DESC");
$query_tahun = mysqli_query($mysqli, "SELECT DISTINCT YEAR(tanggal_ttd) as tahun FROM tbl_pengajuan WHERE status_pengajuan = 'Disetujui' AND tanggal_ttd IS NOT NULL ORDER BY tahun DESC");

// Hitung statistik
$stats_query = mysqli_query($mysqli, "SELECT 
    COUNT(*) as total_riwayat,
    COUNT(CASE WHEN DATE(tanggal_ttd) = CURDATE() THEN 1 END) as hari_ini,
    COUNT(CASE WHEN WEEK(tanggal_ttd) = WEEK(CURDATE()) AND YEAR(tanggal_ttd) = YEAR(CURDATE()) THEN 1 END) as minggu_ini
    FROM tbl_pengajuan WHERE status_pengajuan = 'Disetujui'");
$stats = mysqli_fetch_assoc($stats_query);
?>

<div class="panel-header">
    <div class="page-inner py-4">
        <div class="d-flex align-items-left align-items-md-top flex-column flex-md-row">
            <div class="page-header">
                <h4 class="page-title">
                    <i class="fas fa-history mr-2"></i>
                    Riwayat Pengajuan Tanda Tangan
                </h4>
                <ul class="breadcrumbs">
                    <li class="nav-home"><a href="?module=beranda"><i class="flaticon-home"></i></a></li>
                    <li class="separator"><i class="flaticon-right-arrow"></i></li>
                    <li class="nav-item"><a>Riwayat Pengajuan</a></li>
                </ul>
            </div>
            <div class="ml-md-auto py-2 py-md-0">
                <a href="?module=antrian_surat" class="btn btn-secondary btn-round">
                    <span class="btn-label"><i class="fa fa-arrow-left mr-2"></i></span> Kembali ke Antrian
                </a>
            </div>
        </div>
    </div>
</div>

<div class="page-inner mt--5">
    <!-- Statistik Riwayat -->
    <div class="row">
        <div class="col-sm-6 col-md-4">
            <div class="card card-stats card-round">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-icon">
                            <div class="icon-big text-center icon-success bubble-shadow-small">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                        <div class="col col-stats ml-3 ml-sm-0">
                            <div class="numbers">
                                <p class="card-category">Total Disetujui</p>
                                <h4 class="card-title"><?php echo number_format($stats['total_riwayat']); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-4">
            <div class="card card-stats card-round">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-icon">
                            <div class="icon-big text-center icon-primary bubble-shadow-small">
                                <i class="fas fa-calendar"></i>
                            </div>
                        </div>
                        <div class="col col-stats ml-3 ml-sm-0">
                            <div class="numbers">
                                <p class="card-category">Hari Ini</p>
                                <h4 class="card-title"><?php echo number_format($stats['hari_ini']); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-4">
            <div class="card card-stats card-round">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-icon">
                            <div class="icon-big text-center icon-info bubble-shadow-small">
                                <i class="fas fa-calendar"></i>
                            </div>
                        </div>
                        <div class="col col-stats ml-3 ml-sm-0">
                            <div class="numbers">
                                <p class="card-category">Minggu Ini</p>
                                <h4 class="card-title"><?php echo number_format($stats['minggu_ini']); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter dan Pencarian -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <i class="fas fa-filter mr-2"></i>Filter & Pencarian
                    </div>
                </div>
                <div class="card-body">
                    <form method="GET" action="">
                        <input type="hidden" name="module" value="riwayat_pengajuan">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Pencarian</label>
                                    <input type="text" class="form-control" name="search" 
                                           placeholder="Cari judul, perihal, nomor, atau nama pengaju..."
                                           value="<?php echo htmlspecialchars($search); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Jenis Dokumen</label>
                                    <select class="form-control" name="jenis">
                                        <option value="">Semua Jenis</option>
                                        <?php while ($jenis = mysqli_fetch_assoc($query_jenis)): ?>
                                            <option value="<?php echo $jenis['id_jenis']; ?>" 
                                                <?php echo $jenis_filter == $jenis['id_jenis'] ? 'selected' : ''; ?>>
                                                <?php echo $jenis['nama_jenis']; ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Bulan Tanda Tangan</label>
                                    <select class="form-control" name="bulan">
                                        <option value="">Semua Bulan</option>
                                        <?php while ($bulan = mysqli_fetch_assoc($query_bulan)): ?>
                                            <option value="<?php echo $bulan['bulan']; ?>" 
                                                <?php echo $bulan_filter == $bulan['bulan'] ? 'selected' : ''; ?>>
                                                <?php echo date('F Y', strtotime($bulan['bulan'] . '-01')); ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Tahun Tanda Tangan</label>
                                    <select class="form-control" name="tahun">
                                        <option value="">Semua Tahun</option>
                                        <?php while ($tahun = mysqli_fetch_assoc($query_tahun)): ?>
                                            <option value="<?php echo $tahun['tahun']; ?>" 
                                                <?php echo $tahun_filter == $tahun['tahun'] ? 'selected' : ''; ?>>
                                                <?php echo $tahun['tahun']; ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label> </label>
                                    <div class="btn-group d-block">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-search mr-1"></i> Filter
                                        </button>
                                        <a href="?module=riwayat_pengajuan" class="btn btn-secondary">
                                            <i class="fas fa-undo mr-1"></i> Reset
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Daftar Riwayat -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-list mr-2"></i>
                            Daftar Riwayat Pengajuan (<?php echo number_format($total_data); ?> pengajuan)
                        </h5>
                        <div class="ml-auto">
                            <small class="text-muted">
                                Menampilkan <?php echo $offset + 1; ?> - <?php echo min($offset + $limit, $total_data); ?> dari <?php echo $total_data; ?> data
                            </small>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="thead-light">
                                    <tr>
                                        <th width="5%">#</th>
                                        <th width="15%">Tanggal Tanda Tangan</th>
                                        <th width="15%">Jenis Dokumen</th>
                                        <th width="25%">Judul Surat</th>
                                        <th width="15%">Pengaju</th>
                                        <th width="15%">Catatan Pimpinan</th>
                                        <th width="10%">File Signed</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $no = $offset + 1;
                                    while ($row = mysqli_fetch_assoc($result)): 
                                    ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td>
                                            <div class="text-sm">
                                                <strong><?php echo date('d/m/Y', strtotime($row['tanggal_ttd'])); ?></strong><br>
                                                <small class="text-muted"><?php echo date('H:i', strtotime($row['tanggal_ttd'])); ?></small>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge badge-info"><?php echo $row['nama_jenis']; ?></span>
                                        </td>
                                        <td>
                                            <div class="text-sm">
                                                <strong><?php echo htmlspecialchars($row['judul_surat']); ?></strong>
                                                <?php if (!empty($row['nomor_surat'])): ?>
                                                    <br><small class="text-muted">No: <?php echo htmlspecialchars($row['nomor_surat']); ?></small>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-sm">
                                                <strong><?php echo htmlspecialchars($row['nama_pengaju']); ?></strong>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-sm">
                                                <?php echo htmlspecialchars($row['catatan_pimpinan'] ?: '-'); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if (!empty($row['file_dokumen_signed']) && file_exists($row['file_dokumen_signed'])): ?>
                                                
                                                    <a href="<?php echo htmlspecialchars($row['file_dokumen_signed']); ?>" 
                                                    class="btn btn-sm btn-outline-info" title="Lihat Tanda Tangan" target="_blank">
                                                        <i class="fas fa-eye"></i>
                                                    </a>

                                            <?php elseif (!empty($row['file_dokumen_signed']) && file_exists($row['file_dokumen_signed'])): ?>

                                                <a href="<?php echo htmlspecialchars($row['file_dokumen_signed']); ?>" 
                                                class="btn btn-sm btn-outline-secondary" title="Lihat Dokumen Asli" target="_blank">
                                                    <i class="fas fa-eye"></i>
                                                </a>

                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div>
                                    <small class="text-muted">
                                        Halaman <?php echo $page; ?> dari <?php echo $total_pages; ?>
                                    </small>
                                </div>
                                <nav>
                                    <ul class="pagination pagination-sm mb-0">
                                        <?php if ($page > 1): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="<?php echo buildUrl(array_merge($_GET, ['page' => $page - 1])); ?>">
                                                    <i class="fas fa-chevron-left"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        
                                        <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                            <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                                <a class="page-link" href="<?php echo buildUrl(array_merge($_GET, ['page' => $i])); ?>">
                                                    <?php echo $i; ?>
                                                </a>
                                            </li>
                                        <?php endfor; ?>
                                        
                                        <?php if ($page < $total_pages): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="<?php echo buildUrl(array_merge($_GET, ['page' => $page + 1])); ?>">
                                                    <i class="fas fa-chevron-right"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">Tidak ada riwayat pengajuan</h5>
                            <p class="text-muted">Belum ada pengajuan yang disetujui.</p>
                            <a href="?module=antrian_surat" class="btn btn-primary btn-round">
                                <i class="fas fa-arrow-left mr-2"></i>Kembali ke Antrian
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>

<?php
// Function untuk membuat URL dengan parameter
function buildUrl($params) {
    $url = '?';
    $query_params = [];
    foreach ($params as $key => $value) {
        if (!empty($value)) {
            $query_params[] = $key . '=' . urlencode($value);
        }
    }
    return $url . implode('&', $query_params);
}
?>